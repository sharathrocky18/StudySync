// StudySync frontend (vanilla JS, no build step, no external libraries)
const COLORS = ['var(--c1)', 'var(--c2)', 'var(--c3)', 'var(--c4)', 'var(--c5)', 'var(--c6)'];
const $ = (id) => document.getElementById(id);
const TZ = -new Date().getTimezoneOffset(); // minutes ahead of UTC
const TIMER_KEY = 'studysync.timerStart';

let days = 7;
let timerHandle = null;

/* ---------- helpers ---------- */
const fmtMin = (m) => {
  m = Number(m) || 0;
  if (m > 0 && m < 1) return `${Math.max(Math.round(m * 60), 1)} sec`;
  if (m < 60) return `${Math.round(m * 10) / 10} min`;
  const h = Math.floor(m / 60);
  const r = Math.round(m % 60);
  return r ? `${h}h ${r}m` : `${h}h`;
};
const pad = (n) => String(n).padStart(2, '0');
const fmtClock = (ms) => {
  const s = Math.floor(ms / 1000);
  return `${pad(Math.floor(s / 3600))}:${pad(Math.floor((s % 3600) / 60))}:${pad(s % 60)}`;
};
const fmtWhen = (iso) =>
  new Date(iso).toLocaleString([], { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });

async function api(path, opts) {
  const res = await fetch(path, { headers: { 'content-type': 'application/json' }, ...opts });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Something went wrong');
  return data;
}
function setMsg(text, kind = '') {
  const el = $('msg');
  el.textContent = text;
  el.className = 'msg ' + kind;
  if (kind === 'ok') setTimeout(() => { if (el.textContent === text) el.textContent = ''; }, 3000);
}
function el(tag, props = {}, ...children) {
  const node = Object.assign(document.createElement(tag), props);
  children.forEach((c) => node.append(c));
  return node;
}

/* ---------- rendering ---------- */
function renderStats(s) {
  $('statTotal').textContent = fmtMin(s.totalMinutes);
  $('statSessions').textContent = s.totalSessions;
  $('statAvg').textContent = fmtMin(s.avgPerDay);
  $('statTop').textContent = s.topSubject || '–';
}

function renderBars(s) {
  const box = $('subjectBars');
  box.replaceChildren();
  $('emptyBars').hidden = s.bySubject.length > 0;
  const max = Math.max(...s.bySubject.map((r) => r.minutes), 1);
  s.bySubject.slice(0, 8).forEach((r, i) => {
    const pct = s.totalMinutes ? Math.round((r.minutes / s.totalMinutes) * 100) : 0;
    const fill = el('div', { className: 'bar-fill' });
    fill.style.background = COLORS[i % COLORS.length];
    fill.style.width = '0%';
    requestAnimationFrame(() => (fill.style.width = `${(r.minutes / max) * 100}%`));
    box.append(
      el('div', { className: 'bar-row' },
        el('div', { className: 'meta' }, el('span', { textContent: r.subject }), el('span', { textContent: `${fmtMin(r.minutes)} · ${pct}%` })),
        el('div', { className: 'bar-track' }, fill))
    );
  });
}

function renderDonut(s) {
  const total = s.byCategory.reduce((a, r) => a + r.minutes, 0);
  const legend = $('legend');
  legend.replaceChildren();
  if (!total) {
    $('donut').style.background = 'var(--line)';
    legend.append(el('li', { textContent: 'No data yet' }));
    return;
  }
  const palette = ['#4f46e5', '#0ea5e9', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6'];
  let acc = 0;
  const stops = s.byCategory.map((r, i) => {
    const start = acc;
    acc += (r.minutes / total) * 100;
    return `${palette[i % palette.length]} ${start}% ${acc}%`;
  });
  $('donut').style.background = `conic-gradient(${stops.join(', ')})`;
  s.byCategory.forEach((r, i) => {
    const sw = el('i');
    sw.style.background = palette[i % palette.length];
    legend.append(el('li', {}, sw, r.category, el('span', { className: 'v', textContent: `${Math.round((r.minutes / total) * 100)}%` })));
  });
}

function renderDays(s) {
  const box = $('dayChart');
  box.replaceChildren();
  const max = Math.max(...s.perDay.map((d) => d.minutes), 1);
  const showEvery = s.perDay.length > 14 ? 3 : 1;
  s.perDay.forEach((d, i) => {
    const bar = el('div', { className: 'daybar' + (d.minutes ? '' : ' zero') });
    bar.style.height = '0px';
    requestAnimationFrame(() => (bar.style.height = d.minutes ? `${Math.max((d.minutes / max) * 140, 4)}px` : '2px'));
    const label = new Date(d.day + 'T00:00:00').toLocaleDateString([], s.perDay.length > 7 ? { day: 'numeric', month: 'short' } : { weekday: 'short' });
    bar.title = `${d.day}: ${fmtMin(d.minutes)}`;
    box.append(
      el('div', { className: 'daycol' },
        el('div', { className: 'dayval', textContent: d.minutes && s.perDay.length <= 14 ? fmtMin(d.minutes) : '' }),
        bar,
        el('div', { className: 'daylbl', textContent: i % showEvery === 0 ? label : '' }))
    );
  });
}

function renderRows(rows) {
  const tbody = $('rows');
  tbody.replaceChildren();
  $('emptyRows').hidden = rows.length > 0;
  rows.slice(0, 15).forEach((r) => {
    const del = el('button', { className: 'del', title: 'Delete session', textContent: '✕' });
    del.setAttribute('aria-label', `Delete ${r.subject} session`);
    del.onclick = async () => {
      if (!confirm('Delete this session?')) return;
      await api(`/api/sessions/${r.id}`, { method: 'DELETE' });
      refresh();
    };
    tbody.append(
      el('tr', {},
        el('td', { textContent: fmtWhen(r.started_at) }),
        el('td', { textContent: r.subject }),
        el('td', {}, el('span', { className: 'tag', textContent: r.category })),
        el('td', { className: 'num', textContent: fmtMin(r.duration_min) }),
        el('td', { className: 'notes', textContent: r.notes || '' }),
        el('td', {}, del))
    );
  });
}

/* ---------- data ---------- */
async function refresh() {
  try {
    const [summary, rows] = await Promise.all([
      api(`/api/summary?days=${days}&tz=${TZ}`),
      api('/api/sessions?limit=50'),
    ]);
    renderStats(summary);
    renderBars(summary);
    renderDonut(summary);
    renderDays(summary);
    renderRows(rows);
    // subject suggestions from history
    const subs = [...new Set(rows.map((r) => r.subject))];
    $('subjectList').replaceChildren(...subs.map((s) => el('option', { value: s })));
  } catch (e) {
    setMsg('Could not load data. Is the server running?', 'err');
  }
}

async function saveSession(durationMin, startedAt) {
  const subject = $('subject').value.trim();
  if (!subject) {
    setMsg('Please enter a subject first.', 'err');
    $('subject').focus();
    return false;
  }
  try {
    await api('/api/sessions', {
      method: 'POST',
      body: JSON.stringify({
        subject,
        category: $('category').value,
        notes: $('notes').value,
        started_at: startedAt,
        duration_min: durationMin,
      }),
    });
    setMsg(`Saved ${fmtMin(durationMin)} of ${subject}.`, 'ok');
    $('minutes').value = '';
    $('notes').value = '';
    await refresh();
    return true;
  } catch (e) {
    setMsg(e.message, 'err');
    return false;
  }
}

/* ---------- timer (survives page refresh) ---------- */
function tick() {
  const start = Number(localStorage.getItem(TIMER_KEY));
  if (!start) return;
  $('clock').textContent = fmtClock(Date.now() - start);
}
function setTimerUI(running) {
  $('startBtn').hidden = running;
  $('stopBtn').hidden = !running;
  $('discardBtn').hidden = !running;
  $('clock').classList.toggle('running', running);
  clearInterval(timerHandle);
  if (running) { tick(); timerHandle = setInterval(tick, 500); } else $('clock').textContent = '00:00:00';
}
$('startBtn').onclick = () => {
  localStorage.setItem(TIMER_KEY, String(Date.now()));
  setMsg('');
  setTimerUI(true);
};
$('stopBtn').onclick = async () => {
  const start = Number(localStorage.getItem(TIMER_KEY));
  if (!start) return;
  const minutes = Math.max(Math.round(((Date.now() - start) / 60000) * 10) / 10, 0.1);
  const ok = await saveSession(minutes, new Date(start).toISOString());
  if (ok) { localStorage.removeItem(TIMER_KEY); setTimerUI(false); } // keep running if save failed (e.g. no subject)
};
$('discardBtn').onclick = () => {
  if (!confirm('Discard this running timer?')) return;
  localStorage.removeItem(TIMER_KEY);
  setTimerUI(false);
};

/* ---------- manual form ---------- */
$('form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const mins = Number($('minutes').value);
  if (!mins || mins <= 0) {
    setMsg('Enter the minutes studied, or use the timer above.', 'err');
    $('minutes').focus();
    return;
  }
  // Manual entry is assumed to have just finished
  await saveSession(mins, new Date(Date.now() - mins * 60000).toISOString());
});

/* ---------- range buttons ---------- */
document.querySelectorAll('.range button').forEach((b) => {
  b.onclick = () => {
    document.querySelectorAll('.range button').forEach((x) => x.classList.remove('active'));
    b.classList.add('active');
    days = Number(b.dataset.days);
    refresh();
  };
});

/* ---------- init ---------- */
(async function init() {
  const cats = await api('/api/categories').catch(() => ['Study']);
  $('category').replaceChildren(...cats.map((c) => el('option', { value: c, textContent: c })));
  setTimerUI(!!localStorage.getItem(TIMER_KEY));
  refresh();
})();
